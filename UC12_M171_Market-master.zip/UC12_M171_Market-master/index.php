<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Market M171</title>
    </head>
    <body>
        
        <?php
            require_once 'menu.php';
        ?>
        
        <br> <br> <br> <br> 
        
        <h1 align="center">Bem-vindo ao Market M171 </h1>
        
        <?php
            
        ?>
    </body>
</html>
